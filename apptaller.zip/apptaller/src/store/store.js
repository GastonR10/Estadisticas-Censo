import { configureStore } from "@reduxjs/toolkit";
import personasReducer from "../features/personasSlice";
import ocupacionesSlice from "../features/ocupacionesSlice";
import deptosSlice from "../features/deptosSlice";

export const store = configureStore({
    reducer:{
        personas:personasReducer,
        ocupaciones:ocupacionesSlice,
        deptos:deptosSlice
    }
})
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    deptos: [],
}

export const deptosSlice = createSlice({
    name: "departamentos",
    initialState,
    reducers: {
        guardarDeptos: (state, action) => {
            state.deptos = action.payload;
        }
    }
})

export const { guardarDeptos } = deptosSlice.actions;
export default deptosSlice.reducer;
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
    personas: []
}

export const personasSlice = createSlice({
    name: "personas",
    initialState,
    reducers: {
        guardarPersonas: (state, action) => {
            state.personas = action.payload;
        },

        agregarPersona: (state, action) => {
            state.personas.push(action.payload);
            console.log(state.personas)
        },

        eliminarPersona: (state, action) => {
            const personaIdAEliminar = action.payload;
            state.personas = state.personas.filter(persona => persona.id !== parseInt(personaIdAEliminar));
        }
    }
})

export const { guardarPersonas, agregarPersona, eliminarPersona } = personasSlice.actions;
export default personasSlice.reducer;
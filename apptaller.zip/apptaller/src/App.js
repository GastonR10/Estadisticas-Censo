import { Provider } from "react-redux";
import { store } from "./store/store";
import './App.css';
//import './bootstrap.min.css';
import Cabezal from './componentes/Cabezal'
import Login from './componentes/Login';
import Registro from './componentes/Registro';
import Dashboard from './componentes/Dashboard'; 
import NoEncontrado from "./componentes/NoEncontrado";
import { BrowserRouter, Routes, Route } from "react-router-dom";

function App() {
  return (
    <Provider store={store}>
      <BrowserRouter>
        <Routes>

          <Route path="/" element={<Cabezal />}>
            <Route path="/" element={<Login />}></Route>
            <Route path="/registro" element={<Registro />}></Route>
            <Route path="/dashboard" element={<Dashboard />}></Route>
            <Route path="*" element={<NoEncontrado />}></Route>
          </Route>
         
        </Routes>        
      </BrowserRouter>
      
    </Provider>
  );
}

export default App;

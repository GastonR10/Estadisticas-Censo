
const NoEncontrado = () => {
  return (
    <div>
        <h2>No Encontrado</h2>
    </div>
  )
}

export default NoEncontrado
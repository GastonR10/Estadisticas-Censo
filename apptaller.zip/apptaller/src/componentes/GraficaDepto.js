import { useSelector } from 'react-redux/es/hooks/useSelector';
import { useEffect, useState } from 'react';

import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'top',
        },
        title: {
            display: true,
            text: 'Personas por departamento',
        },
    },
};


const GraficaDepto = () => {
    const deptos = useSelector(state => state.deptos.deptos);

    const personas = useSelector(state => state.personas.personas);

    const [deptosCantidad, setDeptosCantidad] = useState([])

    useEffect(() => {
        let arrayDeptosCantidad = [];

        for (let i = 0; i < deptos.length; i++) {
            arrayDeptosCantidad.push({
                id: deptos[i].id,
                depto: deptos[i].nombre,
                cantPersonas: personas.filter(p => p.departamento == deptos[i].id).length
            })
        }
        setDeptosCantidad(arrayDeptosCantidad);

    }, [personas]);

    return (
        <div className="graficaDepto">
            <h3>Gráfica por Departamento</h3>
            <Bar options={options} data={{
                labels: deptosCantidad
                    .filter(depto => depto.cantPersonas != 0)
                    .map((d) => `${d.depto}`),
                datasets: [
                    {
                        label: 'Cantidad de personas por departamento',
                        data: deptosCantidad
                                .filter(depto => depto.cantPersonas != 0)
                                .map((d) => `${d.cantPersonas}`),
                        backgroundColor: '#BC55ED',
                    }
                ],
            }} />
        </div>
    )
}

export default GraficaDepto
import { useRef, useState, useEffect } from "react"
import { useNavigate } from "react-router-dom"

const Registro = () => {

  const user = useRef(null);
  const pass = useRef(null);

  const [error, setError] = useState("");
  const [mensaje, setMensaje] = useState("");

  let navigate = useNavigate();

  const registrar = () => {
    let usuario = user.current.value;
    let contraseña = pass.current.value;

    let datos = {
      usuario: usuario,
      password: contraseña
    };

    

    fetch('https://censo.develotion.com/usuarios.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(datos)
    })
      .then(response => { return response.json(); })
      .then(data => {

        if (data.codigo !== 200) {
          localStorage.clear();
          setError(true);
          setMensaje(data.mensaje);
        } else {
          localStorage.setItem('tokenUsuarioLogueado', data.apiKey);
          localStorage.setItem('id', data.id);
          navigate("/dashboard");
        }

      })
      .catch(error => console.log(error));
  }

  useEffect(() => {
    if (localStorage.getItem("tokenUsuarioLogueado") !== null) {
      navigate("/dashboard");
    } else {

    }
  }, [])

  return (
    <div className="registro" >
      <h2>Registro</h2>
      <label htmlFor="txtUsuarioRegistro">Usuario</label><br />
      <input type="text" name="txtUsuarioRegistro" id="txtUsuarioRegistro" ref={user}/><br />
      <label htmlFor="txtContraseña">Contraseña</label><br />
      <input type="text" name="txtContraseñaRegistro" id="txtContraseñaRegistro" ref={pass}/><br />
      <input type="button" value="Registrar" onClick={registrar}/>
      <br />
      {error && <p>{mensaje}</p>}
    </div>
  )
}

export default Registro
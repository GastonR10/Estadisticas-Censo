import { useState, useEffect } from "react"
import { Link, useNavigate } from "react-router-dom"


const Login = () => {

  const [userName, setUserName] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [mensaje, setMensaje] = useState("");

  let navigate = useNavigate();

  const ingresar = () => {
    let usuario = userName;
    let contraseña = password;

    let datos = {
      usuario: usuario,
      password: contraseña
    };


    fetch('https://censo.develotion.com/login.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(datos)
    })
      .then(response => { return response.json(); })
      .then(data => {

        if (data.codigo !== 200) {
          localStorage.clear();
          setError(true);
          setMensaje(data.mensaje);
        } else {
          localStorage.setItem('tokenUsuarioLogueado', data.apiKey);
          localStorage.setItem('id', data.id);          
          navigate("/dashboard");
        }
      })
      .catch(error => console.log(error));

  }

  useEffect(() => {
    if (localStorage.getItem("tokenUsuarioLogueado") !== null) {
      navigate("/dashboard");      
    } else {

    }
  }, [])

  const cambiarUsername = (event) => {
    setUserName(event.target.value);
  };

  const cambiarPassword = (event) => {
    setPassword(event.target.value);
  };

  return (
    <div className="login">
      <h2>Login</h2>
      <label htmlFor="txtUsuarioLogin">Usuario</label><br />
      <input type="text" name="txtUsuarioLogin" id="txtUsuarioLogin" onChange={cambiarUsername} /><br />
      <label htmlFor="txtContraseñaLogin">Contraseña</label><br />
      <input type="text" name="txtContraseñaLogin" id="txtContraseñaLogin" onChange={cambiarPassword} /><br />

      <input type="button" value="Ingresar" onClick={ingresar} disabled={userName === '' || password === ''} /><br />

      <br />
      {error && <p>{mensaje}</p>}
      <p>
        Si no tiene cuenta ir a <Link to="/registro">registro</Link>.
      </p>
    </div>
  )
}

export default Login
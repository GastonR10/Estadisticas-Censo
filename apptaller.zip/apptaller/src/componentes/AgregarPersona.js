import { useEffect, useRef, useState } from "react"
import { useDispatch, useSelector } from "react-redux"
import { agregarPersona } from "../features/personasSlice"
import { guardarOcupaciones } from "../features/ocupacionesSlice"
import { guardarDeptos } from "../features/deptosSlice"

const AgregarPersona = () => {

    const dispatch = useDispatch();
    const ocups = useSelector(state => state.ocupaciones.ocupaciones);
    const deptos = useSelector(state => state.deptos.deptos);

    const name = useRef(null);
    const dept = useRef(null);
    const city = useRef(null);
    const date = useRef(null);
    const ocup = useRef(null);

    const [mensaje, setMensaje] = useState("");
    const [ciudades, setCiudades] = useState([]);


    useEffect(() => {
        fetch(`https://censo.develotion.com/departamentos.php`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.codigo !== 200) {

                } else {
                    dispatch(guardarDeptos(data.departamentos))
                }
            })

        fetch(`https://censo.develotion.com/ocupaciones.php`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.codigo !== 200) {

                } else {
                    dispatch(guardarOcupaciones(data.ocupaciones))
                }
            })

    }, [])

    const slcCiudades = () => {
        console.log(localStorage.getItem("tokenUsuarioLogueado"))
        fetch(`https://censo.develotion.com/ciudades.php?idDepartamento=${dept.current.value}`, {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },
        })
            .then(response => response.json())
            .then(data => {
                if (data.codigo !== 200) {
                    setMensaje(data.mensaje);
                } else {
                    setCiudades(data.ciudades)
                }
            })
    }

    const agregar = () => {
        let nombre = name.current.value;
        let departamento = dept.current.value;
        let ciudad = city.current.value;
        let fechaNacimiento = date.current.value;
        let ocupacion = ocup.current.value;
        let id = null;

        let datos = {
            idUsuario: localStorage.getItem("id"),
            nombre,
            departamento,
            ciudad,
            fechaNacimiento,
            ocupacion,
            id
        };

        fetch('https://censo.develotion.com/personas.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },
            body: JSON.stringify(datos)
        })
            .then(response => {
                return response.json();
            })
            .then(data => {
                if (nombre === "" || departamento === "" || ciudad === "" || fechaNacimiento === "" || ocupacion === "") {
                    setMensaje("Ningún campo puede ser vacío");
                } else {
                    if (data.codigo !== 200) {
                        setMensaje(data.mensaje);
                    } else {

                        datos.id = data.idCenso
                        dispatch(agregarPersona(datos));
                        setMensaje(data.mensaje);
                    }
                }

            })
            .catch(error => console.log(error));
    }

    return (
        <div className="agregarPersona">
            <h2>Agregar Persona</h2>
            <label htmlFor="txtNombre">Nombre</label><br />
            <input type="text" name="txtNombre" id="txtNombre" ref={name} /><br />
            <label htmlFor="slcDepto">Departamento</label><br />
            <select name="slcDepto" id="slcDepto" ref={dept} onChange={slcCiudades}>
                <option value="">Seleccionar departamento</option>
                {deptos.map(depto => <option key={depto.id} value={depto.id}>{depto.nombre}</option>)}
            </select> <br />
            <label htmlFor="slcCiudad">Ciudad</label><br />
            <select name="slcCiudad" id="slcCiudad" ref={city}>
                <option value="">Seleccionar ciudad</option>
                {ciudades.map(c => <option key={c.id} value={c.id}>{c.nombre}</option>)}
            </select><br />
            <label htmlFor="txtFechaNac">Fecha de nacimiento</label><br />
            <input type="date" name="txtFechaNac" id="txtFechaNac" ref={date} /><br />
            <label htmlFor="slcOcupacion">Ocupación</label><br />
            <select name="slcOcupacion" id="slcOcupacion" ref={ocup}>
                <option value="">Seleccionar ocupación</option>
                {ocups.map(oc => <option key={oc.id} value={oc.id}>{oc.ocupacion}</option>)}
            </select><br />
            <input type="button" value="Agregar" onClick={agregar} /><br />
            <p>{mensaje}</p>
        </div>
    )
}

export default AgregarPersona
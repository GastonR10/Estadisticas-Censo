import { useEffect } from "react"
import { useNavigate } from "react-router-dom"
import AgregarPersona from "./AgregarPersona"
import ListaPersonas from "./ListaPersonas"
import Censados from "./Censados"
import Analisis from "./Analisis"


const Dashboard = () => {
  let navigate = useNavigate();

  useEffect(() => {
    if (localStorage.getItem("tokenUsuarioLogueado") === null) {
      navigate("/");
    }
  }, [])

  return (
    <div className="dashboard" >
      <div>
        <AgregarPersona />
        <Censados />
      </div>
      <ListaPersonas />
      <Analisis />
    </div>
  )
}

export default Dashboard
import { useEffect, useState } from "react";
import { useDispatch, useSelector } from "react-redux"
import Persona from "./Persona";
import { guardarPersonas } from "../features/personasSlice";


const ListaPersonas = () => {

  const dispatch = useDispatch()
 
  const personas = useSelector(state => state.personas.personas);
 
  const ocupaciones = useSelector(state => state.ocupaciones.ocupaciones);
  const [filtroOcups, setFiltroOcupaciones] = useState("");

  useEffect(() => {

    fetch(`https://censo.develotion.com/personas.php?idUsuario=${localStorage.getItem("id")}`, {
      method: 'GET',
      headers: {
        'Content-Type': 'application/json',
        'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
        'iduser': `${localStorage.getItem("id")}`
      },

    })
      .then(response => response.json())
      .then(data => {
        if (data.codigo !== 200) {
          
        } else {
          dispatch(guardarPersonas(data.personas));
        }
      }
      )
  }, [])

  const filtrar = (event) => {
    const nuevaOcupacion = event.target.value;
    setFiltroOcupaciones(nuevaOcupacion);
  };

  return (
    <div className="personas">
      <h2>Lista Personas</h2>
      <select name="slcOcupacionFiltro" id="slcOcupacionFiltro" onChange={filtrar}>
        <option value="">Filtrar por ocupación</option>
        <option value="">Ver todas</option>
        {ocupaciones.map(oc => <option key={oc.id} value={oc.id}>{oc.id} {oc.ocupacion}</option>)}
      </select><br />
      {personas
        .filter(persona => filtroOcups === "" || persona.ocupacion === parseInt(filtroOcups))
        .map(persona => <Persona key={persona.id} {...persona} />)}
    </div>
  )
}

export default ListaPersonas
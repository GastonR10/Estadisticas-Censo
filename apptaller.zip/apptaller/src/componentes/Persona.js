import { useRef, useState } from "react"
import { useDispatch } from "react-redux"
import { eliminarPersona } from "../features/personasSlice";

const Persona = ({ ...persona }) => {
    const dispatch = useDispatch();

    const [mensaje, setMensaje] = useState("");
    const idPersona = useRef(null);

    const eliminar = () => {
        let id = idPersona.current.getAttribute("data-id");
        console.log(id);
        fetch(`https://censo.develotion.com/personas.php?idCenso=${id}`, {
            method: 'DELETE',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },
            params: {
                'idCenso': id
            }
        })
            .then(response => {
                return response.json();
            })
            .then(data => {

                if (data.codigo !== 200) {
                    setMensaje(data.mensaje + data.codigo);
                } else {
                    setMensaje(data.mensaje);
                    dispatch(eliminarPersona(id));                    
                }

            })
            .catch(error => console.log(error));
    }

    return (
        <div className="persona">
            <p ref={idPersona} data-id={persona.id}>{persona.id} {persona.nombre} {persona.ocupacion}</p>
            <input type="button" value="Eliminar" onClick={eliminar}></input>
            <p>{mensaje}</p>
        </div>
    )
}

export default Persona
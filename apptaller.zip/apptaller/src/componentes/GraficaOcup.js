import { useSelector } from 'react-redux/es/hooks/useSelector';
import { useEffect, useState } from 'react';

import {
    Chart as ChartJS,
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend,
} from 'chart.js';
import { Bar } from 'react-chartjs-2';

ChartJS.register(
    CategoryScale,
    LinearScale,
    BarElement,
    Title,
    Tooltip,
    Legend
);

export const options = {
    responsive: true,
    plugins: {
        legend: {
            position: 'top',
        },
        title: {
            display: true,
            text: 'Personas por ocupación',
        },
    },
};


const GraficaOcup = () => {
    const ocupaciones = useSelector(state => state.ocupaciones.ocupaciones);

    const personas = useSelector(state => state.personas.personas);

    const [ocupCantidad, setOcupCantidad] = useState([])

    useEffect(() => {
        let arrayOcupacionesCantidad = [];

        for (let i = 0; i < ocupaciones.length; i++) {
            arrayOcupacionesCantidad.push({
                id: ocupaciones[i].id,
                ocup: ocupaciones[i].ocupacion,
                cantPersonas: personas.filter(p => p.ocupacion == ocupaciones[i].id).length
            })
        }
        setOcupCantidad(arrayOcupacionesCantidad);

    }, [personas]);

    return (
        <div className="graficaOcup">
            <h3>Gráfica por Ocupación</h3>
            <Bar options={options} data={{
                labels: ocupCantidad
                    .filter(ocup => ocup.cantPersonas != 0)
                    .map((o) => `${o.ocup}`),
                datasets: [
                    {
                        label: 'Cantidad de personas por ocupación',
                        data: ocupCantidad
                                .filter(ocup => ocup.cantPersonas != 0)
                                .map((o) => `${o.cantPersonas}`),
                        backgroundColor: '#BC55ED',
                    }
                ],
            }} />
        </div>
    )
}


export default GraficaOcup
import { NavLink, Outlet } from 'react-router-dom'

const Cabezal = () => {

    const logout = () => {
        localStorage.clear();
    }

    return (
        <div className='cabezal'>
            
                <h1>App de senso</h1>
                <nav>
                    <NavLink to="/">Inicio</NavLink>
                    <NavLink to="/registro">Registro</NavLink>
                    <NavLink to="/dashboard">Dashboard</NavLink>
                    <NavLink to="/" onClick={logout}>Cerrar Sesión</NavLink>
                </nav>
                <hr />
            
          
                <Outlet />
            
        </div>
    )
}

export default Cabezal
import { useSelector } from 'react-redux/es/hooks/useSelector';
import { useEffect, useState } from 'react';
import { MapContainer, TileLayer, Marker, Popup } from 'react-leaflet';
import 'leaflet/dist/leaflet.css';
import L from 'leaflet';

delete L.Icon.Default.prototype._getIconUrl;

L.Icon.Default.mergeOptions({
    iconRetinaUrl: require('leaflet/dist/images/marker-icon-2x.png'),
    iconUrl: require('leaflet/dist/images/marker-icon.png'),
    shadowUrl: require('leaflet/dist/images/marker-shadow.png')
});

const Mapa = () => {
    const deptos = useSelector(state => state.deptos.deptos);

    const personas = useSelector(state => state.personas.personas);

    const [deptosMapa, setDeptosMapa] = useState([])

    useEffect(() => {
        let arrayDeptosMapa = [];

        for (let i = 0; i < deptos.length; i++) {
            arrayDeptosMapa.push({
                id: deptos[i].id,
                depto: deptos[i].nombre,
                cantPersonas: personas.filter(p => p.departamento == deptos[i].id).length,
                latitud: deptos[i].latitud,
                longitud: deptos[i].longitud
            })
        }
        setDeptosMapa(arrayDeptosMapa);

    }, [personas]);

    return (
        <div className='mapa'>
            <h3>Mapa</h3>
            <MapContainer id="mapContainer" center={[-33, -56]} zoom={6} scrollWheelZoom={false} style={{ width: "100%", height: "400px" }}>
                <TileLayer
                    attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
                    url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
                />
                {deptosMapa.map( elem => <Marker key={elem.id} position={[elem.latitud, elem.longitud]}>
                    <Popup>
                        {parseInt(elem.cantPersonas)} personas censadas por el usuario en {elem.depto}
                    </Popup>
                </Marker>)}
            </MapContainer>
        </div>
    )

}

export default Mapa
import { useSelector } from "react-redux"

const Censados = () => {

    const cantTotal = useSelector(state => state.personas.personas.length);
    const cantMontevideo = useSelector(state => state.personas.personas.filter(pers => pers.departamento == 3218).length);

    return (
        <div className="censados">
            <h2>Censados</h2>
            <p>Total censados: <strong>{cantTotal}</strong></p>
            <p>Montevideo: <strong>{cantMontevideo}</strong></p>
            <p>Resto del país: <strong>{cantTotal - cantMontevideo}</strong></p>
        </div>
    )
}

export default Censados
import GraficaDepto from './GraficaDepto'
import GraficaOcup from './GraficaOcup'
import Mapa from './Mapa'
import Porcentaje from './Porcentaje'
import TiempoRestante from './TiempoRestante'
const Analisis = () => {
    return (
        <div className="analisis">
            <h2>Análisis</h2>

            <div className="mapaporcentiempo">                
                <div className="porcentiempo">
                    <Porcentaje />
                    <TiempoRestante />
                </div>
                <Mapa />
            </div>
            <div className="graficas">
                <GraficaDepto />
                <GraficaOcup />
            </div>


        </div>
    )
}

export default Analisis
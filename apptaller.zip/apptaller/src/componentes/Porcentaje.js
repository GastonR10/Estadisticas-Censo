import { useEffect, useState } from 'react'
import { useSelector } from 'react-redux/es/hooks/useSelector';



const Porcentaje = () => {
    const personas = useSelector(state => state.personas.personas)

    const censosUsuario = useSelector(state => state.personas.personas).length

    const [totalCensados, setTotalCensados] = useState();

    useEffect(() => {
        fetch('https://censo.develotion.com/totalCensados.php', {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json',
                'apikey': `${localStorage.getItem("tokenUsuarioLogueado")}`,
                'iduser': `${localStorage.getItem("id")}`
            },

        })
            .then(response => {
                return response.json();
            })
            .then(data => {
                setTotalCensados(data.total);
            })
            .catch(error => console.log(error));
    }, [personas])

    return (
        <div className='porcentaje'>
            <h3>Porcentaje</h3>
            <p>El usuario realizó {censosUsuario} censos, sobre {totalCensados} en todo el país.</p>
            <p>Esto representa el {(censosUsuario / totalCensados * 100).toFixed(2)}% de los censos.</p>
        </div>
    )
}

export default Porcentaje
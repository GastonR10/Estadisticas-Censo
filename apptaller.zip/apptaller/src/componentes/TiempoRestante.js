const TiempoRestante = () => {
    const fechaObjetivo = new Date('2023-08-31');
    const fechaActual = new Date();

    const diasFaltantes = fechaObjetivo - fechaActual

    return (
        <div className='tiempoRestante'>
            <h3>Tiempo Restante</h3>
            <p>Faltan {Math.ceil(diasFaltantes / (1000 * 60 * 60 * 24))} días para el final del censo.</p>
        </div>
    )
}

export default TiempoRestante